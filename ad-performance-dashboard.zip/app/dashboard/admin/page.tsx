"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Users,
  UserPlus,
  Trash2,
  Mail,
  ShieldCheck,
  Upload,
  FileJson,
  CheckCircle,
  AlertCircle,
  Settings,
  Database,
  Clock,
} from "lucide-react"

interface FacultyMember {
  email: string
  name: string
  addedAt: string
  status: "active" | "pending"
}

export default function AdminPage() {
  const { user, isAdmin } = useAuth()
  const router = useRouter()
  const [faculty, setFaculty] = useState<FacultyMember[]>([])
  const [newEmail, setNewEmail] = useState("")
  const [newName, setNewName] = useState("")
  const [jsonData, setJsonData] = useState("")
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  useEffect(() => {
    if (!isAdmin) {
      router.push("/dashboard")
      return
    }
    // Load faculty list from localStorage
    const storedFaculty = localStorage.getItem("aiba_faculty_list")
    if (storedFaculty) {
      setFaculty(JSON.parse(storedFaculty))
    }
  }, [isAdmin, router])

  const addFaculty = () => {
    if (!newEmail.trim()) return

    const newMember: FacultyMember = {
      email: newEmail.trim().toLowerCase(),
      name: newName.trim() || newEmail.split("@")[0],
      addedAt: new Date().toISOString(),
      status: "pending",
    }

    const updatedFaculty = [...faculty, newMember]
    setFaculty(updatedFaculty)
    localStorage.setItem("aiba_faculty_list", JSON.stringify(updatedFaculty))
    setNewEmail("")
    setNewName("")
    setIsAddDialogOpen(false)
  }

  const removeFaculty = (email: string) => {
    const updatedFaculty = faculty.filter((f) => f.email !== email)
    setFaculty(updatedFaculty)
    localStorage.setItem("aiba_faculty_list", JSON.stringify(updatedFaculty))
  }

  const handleJsonUpload = () => {
    try {
      const parsed = JSON.parse(jsonData)
      // Validate JSON structure
      if (Array.isArray(parsed) || typeof parsed === "object") {
        localStorage.setItem("aiba_campaign_data", jsonData)
        setUploadStatus("success")
        setTimeout(() => setUploadStatus("idle"), 3000)
      } else {
        setUploadStatus("error")
      }
    } catch {
      setUploadStatus("error")
      setTimeout(() => setUploadStatus("idle"), 3000)
    }
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Admin Settings</h1>
          <p className="text-sm text-muted-foreground">
            Manage users and dashboard settings
          </p>
        </div>
        <Badge className="bg-[#1877F2]/10 text-[#1877F2] hover:bg-[#1877F2]/10">
          <ShieldCheck className="w-3 h-3 mr-1" />
          Admin Access
        </Badge>
      </div>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />
            User Management
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          {/* Stats */}
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#1877F2]/10 rounded-lg">
                    <Users className="w-5 h-5 text-[#1877F2]" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{faculty.length + 2}</p>
                    <p className="text-xs text-muted-foreground">Total Users</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-50 rounded-lg">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">1</p>
                    <p className="text-xs text-muted-foreground">Admins</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-50 rounded-lg">
                    <Clock className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{faculty.filter((f) => f.status === "pending").length}</p>
                    <p className="text-xs text-muted-foreground">Pending Invites</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Faculty List */}
          <Card className="border-border/50">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Faculty Members</CardTitle>
                  <CardDescription>Add or remove faculty access to the dashboard</CardDescription>
                </div>
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[#1877F2] hover:bg-[#1877F2]/90">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add Faculty
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Faculty Member</DialogTitle>
                      <DialogDescription>
                        Add a new faculty member to access the dashboard. They will use the default password: faculty123
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="faculty@armyiba.edu.bd"
                          value={newEmail}
                          onChange={(e) => setNewEmail(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="name">Name (Optional)</Label>
                        <Input
                          id="name"
                          placeholder="Faculty Name"
                          value={newName}
                          onChange={(e) => setNewName(e.target.value)}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={addFaculty} className="bg-[#1877F2] hover:bg-[#1877F2]/90">
                        Add Faculty
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {/* Demo Users */}
                <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-[#1877F2]/10 rounded-full flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4 text-[#1877F2]" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">Admin User</p>
                      <p className="text-xs text-muted-foreground">admin@armyiba.edu.bd</p>
                    </div>
                  </div>
                  <Badge className="bg-[#1877F2]/10 text-[#1877F2]">Admin</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-emerald-50 rounded-full flex items-center justify-center">
                      <Users className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">Faculty Member</p>
                      <p className="text-xs text-muted-foreground">faculty@armyiba.edu.bd</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-emerald-600 border-emerald-200">Demo</Badge>
                </div>

                {/* Dynamic Faculty List */}
                {faculty.map((member) => (
                  <div key={member.email} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center">
                        <Mail className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{member.name}</p>
                        <p className="text-xs text-muted-foreground">{member.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className={member.status === "active" ? "text-emerald-600 border-emerald-200" : "text-amber-600 border-amber-200"}
                      >
                        {member.status === "active" ? "Active" : "Pending"}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => removeFaculty(member.email)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                {faculty.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No additional faculty members added yet.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-4">
          {/* JSON Upload */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <FileJson className="w-5 h-5 text-[#1877F2]" />
                Campaign Data Upload
              </CardTitle>
              <CardDescription>
                Upload JSON data to update campaign metrics and reports
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {uploadStatus === "success" && (
                <Alert className="border-emerald-200 bg-emerald-50">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <AlertDescription className="text-emerald-700">
                    JSON data uploaded successfully!
                  </AlertDescription>
                </Alert>
              )}
              {uploadStatus === "error" && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription>
                    Invalid JSON format. Please check your data and try again.
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="json-data">JSON Data</Label>
                <Textarea
                  id="json-data"
                  placeholder='{"campaigns": [...], "cycles": [...]}'
                  className="font-mono text-sm h-48"
                  value={jsonData}
                  onChange={(e) => setJsonData(e.target.value)}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleJsonUpload}
                  disabled={!jsonData.trim()}
                  className="bg-[#1877F2] hover:bg-[#1877F2]/90"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Data
                </Button>
                <Button variant="outline" onClick={() => setJsonData("")}>
                  Clear
                </Button>
              </div>

              <div className="p-3 bg-muted/30 rounded-lg">
                <h4 className="font-medium text-sm mb-2">Expected JSON Structure</h4>
                <pre className="text-xs text-muted-foreground font-mono overflow-auto">
{`{
  "campaigns": [
    {
      "id": "campaign-id",
      "name": "Campaign Name",
      "spend": 50000,
      "messages": 2500,
      ...
    }
  ],
  "cycles": [
    {
      "cycle": 1,
      "dates": "Jan 04-06",
      "spend": 4200,
      ...
    }
  ]
}`}
                </pre>
              </div>
            </CardContent>
          </Card>

          {/* Database Info */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Database className="w-5 h-5 text-[#1877F2]" />
                Storage Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Storage Type</span>
                  <span className="font-medium">Browser localStorage</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Campaign Data</span>
                  <Badge variant="outline">
                    {localStorage.getItem("aiba_campaign_data") ? "Custom" : "Default"}
                  </Badge>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Faculty List</span>
                  <span className="font-medium">{faculty.length} members</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Last Updated</span>
                  <span className="font-medium">{new Date().toLocaleDateString()}</span>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full mt-4 text-destructive hover:text-destructive bg-transparent"
                onClick={() => {
                  if (confirm("This will clear all custom data. Are you sure?")) {
                    localStorage.removeItem("aiba_campaign_data")
                    localStorage.removeItem("aiba_faculty_list")
                    setFaculty([])
                    setJsonData("")
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Reset All Custom Data
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
