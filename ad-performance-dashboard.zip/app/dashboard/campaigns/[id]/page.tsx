"use client"

import { useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  BarChart3,
  MessageCircle,
  Eye,
  Wallet,
  Users,
  Target,
  TrendingUp,
  Smartphone,
  Monitor,
  MapPin,
} from "lucide-react"
import Link from "next/link"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const campaignData: Record<string, {
  name: string
  status: string
  objective: string
  dateRange: string
  metrics: {
    spend: number
    messages?: number
    engagements?: number
    cpm: number
    ctr: number
    frequency: number
    reach: number
    impressions: number
  }
  spendOverTime: { date: string; spend: number }[]
  resultsOverTime: { date: string; results: number }[]
  impressionsOverTime: { date: string; impressions: number }[]
  geography: { region: string; percentage: number; results: number }[]
  placements: { name: string; percentage: number; spend: number }[]
  devices: { name: string; percentage: number }[]
}> = {
  "aiba-n3": {
    name: "aiba n 3",
    status: "Active",
    objective: "Sales",
    dateRange: "Jan 04 – Jan 19, 2026",
    metrics: {
      spend: 52390,
      messages: 2587,
      cpm: 18.32,
      ctr: 0.16,
      frequency: 7.6,
      reach: 375277,
      impressions: 2860000,
    },
    spendOverTime: [
      { date: "Jan 04", spend: 4200 },
      { date: "Jan 06", spend: 4380 },
      { date: "Jan 08", spend: 4100 },
      { date: "Jan 10", spend: 3900 },
      { date: "Jan 12", spend: 4650 },
      { date: "Jan 14", spend: 4300 },
      { date: "Jan 16", spend: 4550 },
      { date: "Jan 18", spend: 3800 },
      { date: "Jan 19", spend: 4820 },
    ],
    resultsOverTime: [
      { date: "Jan 04", results: 210 },
      { date: "Jan 06", results: 245 },
      { date: "Jan 08", results: 198 },
      { date: "Jan 10", results: 312 },
      { date: "Jan 12", results: 287 },
      { date: "Jan 14", results: 356 },
      { date: "Jan 16", results: 298 },
      { date: "Jan 18", results: 342 },
      { date: "Jan 19", results: 389 },
    ],
    impressionsOverTime: [
      { date: "Jan 04", impressions: 280000 },
      { date: "Jan 06", impressions: 310000 },
      { date: "Jan 08", impressions: 295000 },
      { date: "Jan 10", impressions: 340000 },
      { date: "Jan 12", impressions: 380000 },
      { date: "Jan 14", impressions: 420000 },
      { date: "Jan 16", impressions: 390000 },
      { date: "Jan 18", impressions: 445000 },
    ],
    geography: [
      { region: "Sylhet Division", percentage: 68, results: 1759 },
      { region: "Dhaka Division", percentage: 18, results: 466 },
      { region: "Chittagong Division", percentage: 8, results: 207 },
      { region: "Other Divisions", percentage: 6, results: 155 },
    ],
    placements: [
      { name: "Facebook Feed", percentage: 45, spend: 23575 },
      { name: "Instagram Feed", percentage: 28, spend: 14669 },
      { name: "Facebook Stories", percentage: 15, spend: 7858 },
      { name: "Instagram Reels", percentage: 12, spend: 6287 },
    ],
    devices: [
      { name: "Mobile", percentage: 92 },
      { name: "Desktop", percentage: 8 },
    ],
  },
  "aiba-carusol": {
    name: "Aiba Carusol ad",
    status: "Off",
    objective: "Sales",
    dateRange: "Nov 16 – Jan 03, 2026",
    metrics: {
      spend: 88830,
      messages: 4200,
      cpm: 27.76,
      ctr: 0.18,
      frequency: 7.6,
      reach: 420000,
      impressions: 3200000,
    },
    spendOverTime: [
      { date: "Nov 16", spend: 3200 },
      { date: "Nov 22", spend: 4500 },
      { date: "Nov 28", spend: 5200 },
      { date: "Dec 04", spend: 6100 },
      { date: "Dec 10", spend: 5800 },
      { date: "Dec 16", spend: 6500 },
      { date: "Dec 22", spend: 7200 },
      { date: "Dec 28", spend: 6800 },
      { date: "Jan 03", spend: 5530 },
    ],
    resultsOverTime: [
      { date: "Nov 16", results: 180 },
      { date: "Nov 22", results: 310 },
      { date: "Nov 28", results: 420 },
      { date: "Dec 04", results: 480 },
      { date: "Dec 10", results: 520 },
      { date: "Dec 16", results: 580 },
      { date: "Dec 22", results: 640 },
      { date: "Dec 28", results: 590 },
      { date: "Jan 03", results: 480 },
    ],
    impressionsOverTime: [
      { date: "Nov 16", impressions: 220000 },
      { date: "Nov 22", impressions: 340000 },
      { date: "Nov 28", impressions: 380000 },
      { date: "Dec 04", impressions: 420000 },
      { date: "Dec 10", impressions: 450000 },
      { date: "Dec 16", impressions: 480000 },
      { date: "Dec 22", impressions: 510000 },
      { date: "Dec 28", impressions: 400000 },
    ],
    geography: [
      { region: "Sylhet Division", percentage: 72, results: 3024 },
      { region: "Dhaka Division", percentage: 15, results: 630 },
      { region: "Chittagong Division", percentage: 8, results: 336 },
      { region: "Other Divisions", percentage: 5, results: 210 },
    ],
    placements: [
      { name: "Facebook Feed", percentage: 48, spend: 42638 },
      { name: "Instagram Feed", percentage: 25, spend: 22207 },
      { name: "Facebook Stories", percentage: 16, spend: 14213 },
      { name: "Instagram Reels", percentage: 11, spend: 9771 },
    ],
    devices: [
      { name: "Mobile", percentage: 94 },
      { name: "Desktop", percentage: 6 },
    ],
  },
}

// Default campaign data for campaigns not explicitly defined
const defaultCampaign = {
  name: "Campaign",
  status: "Off",
  objective: "Sales",
  dateRange: "Nov 16 – Jan 19, 2026",
  metrics: {
    spend: 5000,
    messages: 250,
    cpm: 20.00,
    ctr: 0.15,
    frequency: 7.0,
    reach: 25000,
    impressions: 250000,
  },
  spendOverTime: [
    { date: "Day 1", spend: 500 },
    { date: "Day 3", spend: 600 },
    { date: "Day 5", spend: 700 },
    { date: "Day 7", spend: 800 },
    { date: "Day 9", spend: 650 },
  ],
  resultsOverTime: [
    { date: "Day 1", results: 25 },
    { date: "Day 3", results: 35 },
    { date: "Day 5", results: 45 },
    { date: "Day 7", results: 55 },
    { date: "Day 9", results: 40 },
  ],
  impressionsOverTime: [
    { date: "Day 1", impressions: 25000 },
    { date: "Day 3", impressions: 35000 },
    { date: "Day 5", impressions: 45000 },
    { date: "Day 7", impressions: 55000 },
    { date: "Day 9", impressions: 40000 },
  ],
  geography: [
    { region: "Sylhet Division", percentage: 70, results: 175 },
    { region: "Dhaka Division", percentage: 20, results: 50 },
    { region: "Other", percentage: 10, results: 25 },
  ],
  placements: [
    { name: "Facebook Feed", percentage: 50, spend: 2500 },
    { name: "Instagram Feed", percentage: 30, spend: 1500 },
    { name: "Stories", percentage: 20, spend: 1000 },
  ],
  devices: [
    { name: "Mobile", percentage: 90 },
    { name: "Desktop", percentage: 10 },
  ],
}

const COLORS = ["#1877F2", "#E1306C", "#00a884", "#0084ff", "#f59e0b"]

export default function CampaignDetailPage() {
  const params = useParams()
  const campaignId = params.id as string
  const campaign = campaignData[campaignId] || { ...defaultCampaign, name: campaignId }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link href="/dashboard/campaigns">
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-12 h-12 bg-emerald-700 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">{campaign.name}</h1>
            <div className="flex items-center gap-2 mt-0.5">
              <Badge
                variant="secondary"
                className={`text-xs ${
                  campaign.status === "Active"
                    ? "bg-emerald-100 text-emerald-700"
                    : campaign.status === "Ended recently"
                    ? "bg-amber-100 text-amber-700"
                    : "bg-gray-100 text-gray-600"
                }`}
              >
                {campaign.status}
              </Badge>
              <span className="text-xs text-muted-foreground">{campaign.objective}</span>
              <span className="text-xs text-muted-foreground">•</span>
              <span className="text-xs text-muted-foreground">{campaign.dateRange}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {[
          { label: "Spend", value: `৳${campaign.metrics.spend.toLocaleString()}`, icon: Wallet, color: "text-emerald-600" },
          { label: campaign.metrics.messages ? "Messages" : "Engagements", value: (campaign.metrics.messages || campaign.metrics.engagements || 0).toLocaleString(), icon: MessageCircle, color: "text-[#1877F2]" },
          { label: "CPM", value: `৳${campaign.metrics.cpm.toFixed(2)}`, icon: Target, color: "text-amber-600" },
          { label: "CTR", value: `${campaign.metrics.ctr}%`, icon: TrendingUp, color: "text-purple-600" },
          { label: "Frequency", value: campaign.metrics.frequency.toFixed(1), icon: BarChart3, color: "text-rose-600" },
          { label: "Reach", value: `${(campaign.metrics.reach / 1000).toFixed(0)}K`, icon: Users, color: "text-indigo-600" },
          { label: "Impressions", value: `${(campaign.metrics.impressions / 1000000).toFixed(2)}M`, icon: Eye, color: "text-cyan-600" },
        ].map((metric) => (
          <Card key={metric.label} className="border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <metric.icon className={`w-4 h-4 ${metric.color}`} />
                <span className="text-xs text-muted-foreground">{metric.label}</span>
              </div>
              <p className="text-xl font-bold">{metric.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <Tabs defaultValue="spend" className="space-y-4">
        <TabsList>
          <TabsTrigger value="spend">Spend Over Time</TabsTrigger>
          <TabsTrigger value="results">Results Over Time</TabsTrigger>
          <TabsTrigger value="impressions">Impressions</TabsTrigger>
        </TabsList>

        <TabsContent value="spend">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-sm font-medium">Daily Spend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={campaign.spendOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip
                    formatter={(value) => [`৳${Number(value).toLocaleString()}`, "Spend"]}
                    contentStyle={{ fontSize: 12 }}
                  />
                  <Bar dataKey="spend" fill="#1877F2" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-sm font-medium">Results Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={campaign.resultsOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ fontSize: 12 }} />
                  <Line
                    type="monotone"
                    dataKey="results"
                    stroke="#00a884"
                    strokeWidth={2}
                    dot={{ fill: "#00a884" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="impressions">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-sm font-medium">Impressions Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={campaign.impressionsOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                  <Tooltip
                    formatter={(value) => [Number(value).toLocaleString(), "Impressions"]}
                    contentStyle={{ fontSize: 12 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="impressions"
                    stroke="#E1306C"
                    strokeWidth={2}
                    dot={{ fill: "#E1306C" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Breakdowns */}
      <div className="grid md:grid-cols-3 gap-4">
        {/* Geography */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#1877F2]" />
              Geography (Sylhet-focused)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {campaign.geography.map((geo, index) => (
              <div key={geo.region}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">{geo.region}</span>
                  <span className="font-medium">{geo.percentage}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${geo.percentage}%`,
                      backgroundColor: COLORS[index % COLORS.length],
                    }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">{geo.results.toLocaleString()} results</p>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Placements */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#1877F2]" />
              Placements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie
                  data={campaign.placements}
                  dataKey="percentage"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                >
                  {campaign.placements.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value}%`, "Share"]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1 mt-2">
              {campaign.placements.map((placement, index) => (
                <div key={placement.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="text-muted-foreground">{placement.name}</span>
                  </div>
                  <span className="font-medium">৳{placement.spend.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Devices */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-[#1877F2]" />
              Devices
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaign.devices.map((device) => (
                <div key={device.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {device.name === "Mobile" ? (
                        <Smartphone className="w-4 h-4 text-[#1877F2]" />
                      ) : (
                        <Monitor className="w-4 h-4 text-muted-foreground" />
                      )}
                      <span className="text-sm">{device.name}</span>
                    </div>
                    <span className="text-sm font-bold">{device.percentage}%</span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#1877F2] rounded-full"
                      style={{ width: `${device.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Mobile dominates with {campaign.devices[0].percentage}% of impressions, typical for Bangladesh market.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
