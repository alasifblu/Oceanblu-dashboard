"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  BarChart3,
  Search,
  Filter,
  MoreHorizontal,
  ArrowUpRight,
} from "lucide-react"
import Link from "next/link"
import { useState, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import Loading from "./loading"

const allCampaigns = [
  {
    id: "aiba-n3",
    name: "aiba n 3",
    status: "Active",
    objective: "Sales",
    messages: 2587,
    cpr: 20.25,
    spent: 52390,
    reach: 375277,
    impressions: 2860000,
    ctr: 0.16,
    frequency: 7.6,
    dateRange: "Jan 04 – Jan 19, 2026",
  },
  {
    id: "army-iba-news",
    name: "army iba news 2 feb",
    status: "Ended recently",
    objective: "Engagement",
    engagements: 6260,
    cpr: 0.33,
    spent: 2088.83,
    reach: 45000,
    impressions: 320000,
    ctr: 0.22,
    frequency: 7.1,
    dateRange: "Jan 15 – Feb 02, 2026",
  },
  {
    id: "aiba-2",
    name: "aiba 2",
    status: "Off",
    objective: "Sales",
    messages: 47,
    cpr: 37.03,
    spent: 1740.35,
    reach: 12500,
    impressions: 89000,
    ctr: 0.11,
    frequency: 7.1,
    dateRange: "Dec 10 – Dec 25, 2025",
  },
  {
    id: "new-sales",
    name: "New Sales campaign",
    status: "Off",
    objective: "Sales",
    messages: 108,
    cpr: 20.27,
    spent: 2188.90,
    reach: 18200,
    impressions: 145000,
    ctr: 0.14,
    frequency: 8.0,
    dateRange: "Nov 20 – Dec 05, 2025",
  },
  {
    id: "aiba-carusol",
    name: "Aiba Carusol ad",
    status: "Off",
    objective: "Sales",
    messages: 4200,
    cpr: 21.15,
    spent: 88830,
    reach: 420000,
    impressions: 3200000,
    ctr: 0.18,
    frequency: 7.6,
    dateRange: "Nov 16 – Jan 03, 2026",
  },
  {
    id: "army-iba-news-old",
    name: "Army IBA NEWS",
    status: "Off",
    objective: "Sales",
    messages: 1900,
    cpr: 22.50,
    spent: 42750,
    reach: 180000,
    impressions: 1350000,
    ctr: 0.15,
    frequency: 7.5,
    dateRange: "Nov 16 – Jan 03, 2026",
  },
]

export default function CampaignsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const searchParams = useSearchParams()

  const filteredCampaigns = allCampaigns.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || campaign.status.toLowerCase().includes(statusFilter.toLowerCase())
    return matchesSearch && matchesStatus
  })

  return (
    <Suspense fallback={<Loading />}>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Campaigns</h1>
            <p className="text-sm text-muted-foreground">
              Manage and monitor all advertising campaigns
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search campaigns..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="off">Off</SelectItem>
              <SelectItem value="ended">Ended</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Campaigns Table */}
        <Card className="border-border/50">
          <CardHeader className="pb-0">
            <CardTitle className="text-sm font-medium">
              {filteredCampaigns.length} Campaigns
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left text-xs font-medium text-muted-foreground px-4 py-3">Campaign</th>
                    <th className="text-left text-xs font-medium text-muted-foreground px-4 py-3">Status</th>
                    <th className="text-right text-xs font-medium text-muted-foreground px-4 py-3">Results</th>
                    <th className="text-right text-xs font-medium text-muted-foreground px-4 py-3">Reach</th>
                    <th className="text-right text-xs font-medium text-muted-foreground px-4 py-3">CPR</th>
                    <th className="text-right text-xs font-medium text-muted-foreground px-4 py-3">Spent</th>
                    <th className="text-right text-xs font-medium text-muted-foreground px-4 py-3">CTR</th>
                    <th className="text-center text-xs font-medium text-muted-foreground px-4 py-3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns.map((campaign) => (
                    <tr key={campaign.id} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 bg-emerald-700 rounded-lg flex items-center justify-center shrink-0">
                            <BarChart3 className="w-4 h-4 text-white" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">{campaign.name}</p>
                            <p className="text-[10px] text-muted-foreground">{campaign.dateRange}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant="secondary"
                          className={`text-[10px] ${
                            campaign.status === "Active"
                              ? "bg-emerald-100 text-emerald-700"
                              : campaign.status === "Ended recently"
                              ? "bg-amber-100 text-amber-700"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {campaign.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <p className="font-medium text-sm">
                          {(campaign.messages || campaign.engagements)?.toLocaleString()}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {campaign.messages ? "Messages" : "Engagements"}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <p className="font-medium text-sm">{(campaign.reach / 1000).toFixed(0)}K</p>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <p className="font-medium text-sm">৳{campaign.cpr.toFixed(2)}</p>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <p className="font-medium text-sm">৳{campaign.spent.toLocaleString()}</p>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <p className="font-medium text-sm">{campaign.ctr}%</p>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <Link href={`/dashboard/campaigns/${campaign.id}`}>
                          <Button variant="ghost" size="sm" className="h-8">
                            <ArrowUpRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Suspense>
  )
}
