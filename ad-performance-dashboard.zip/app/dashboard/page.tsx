"use client"

import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { KPICards } from "@/components/dashboard/kpi-cards"
import { ExecutiveSummary } from "@/components/dashboard/executive-summary"
import { AdmissionsFunnel } from "@/components/dashboard/admissions-funnel"
import { PerformanceCharts } from "@/components/dashboard/performance-charts"
import { CyclePerformanceTable } from "@/components/dashboard/cycle-performance-table"
import { PlacementInsights } from "@/components/dashboard/placement-insights"
import { CombinedSummary } from "@/components/dashboard/combined-summary"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <div className="container mx-auto px-4 py-8 space-y-8">
        <KPICards />
        <ExecutiveSummary />
        <AdmissionsFunnel />
        <PerformanceCharts />
        <CyclePerformanceTable />
        <PlacementInsights />
        <CombinedSummary />
      </div>
    </div>
  )
}
