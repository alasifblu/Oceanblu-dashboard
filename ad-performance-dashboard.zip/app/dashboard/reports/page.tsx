"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  FileText,
  Download,
  FileSpreadsheet,
  Calendar,
  CheckCircle,
  Eye,
} from "lucide-react"

// Report data
const cycleData = [
  { cycle: 1, dates: "Jan 04–06", campaign: "Aiba Carusol ad", spend: 4200, messages: 198, cpr: 21.21, reach: 28500, ctr: 0.15 },
  { cycle: 2, dates: "Jan 06–08", campaign: "Army IBA NEWS", spend: 4380, messages: 195, cpr: 22.46, reach: 29200, ctr: 0.14 },
  { cycle: 3, dates: "Jan 08–09", campaign: "Aiba Carusol ad", spend: 4100, messages: 205, cpr: 20.00, reach: 27800, ctr: 0.16 },
  { cycle: 4, dates: "Jan 09–11", campaign: "Army IBA NEWS", spend: 3900, messages: 182, cpr: 21.43, reach: 26500, ctr: 0.15 },
  { cycle: 5, dates: "Jan 11–13", campaign: "Aiba Carusol ad", spend: 4650, messages: 220, cpr: 21.14, reach: 31200, ctr: 0.17 },
  { cycle: 6, dates: "Jan 13–15", campaign: "Army IBA NEWS", spend: 4300, messages: 208, cpr: 20.67, reach: 29800, ctr: 0.16 },
  { cycle: 7, dates: "Jan 15–16", campaign: "Aiba Carusol ad", spend: 4550, messages: 228, cpr: 19.96, reach: 30500, ctr: 0.18 },
  { cycle: 8, dates: "Jan 16–17", campaign: "Army IBA NEWS", spend: 3800, messages: 185, cpr: 20.54, reach: 25600, ctr: 0.15 },
  { cycle: 9, dates: "Jan 17–18", campaign: "Aiba Carusol ad", spend: 4050, messages: 198, cpr: 20.45, reach: 27200, ctr: 0.16 },
  { cycle: 10, dates: "Jan 18–19", campaign: "Army IBA NEWS", spend: 3900, messages: 188, cpr: 20.74, reach: 26800, ctr: 0.15 },
  { cycle: 11, dates: "Jan 19 (Manual)", campaign: "Aiba Carusol ad", spend: 4200, messages: 210, cpr: 20.00, reach: 28500, ctr: 0.17 },
  { cycle: 12, dates: "Jan 19 (Threshold)", campaign: "Army IBA NEWS", spend: 4150, messages: 198, cpr: 20.96, reach: 27800, ctr: 0.16 },
  { cycle: 13, dates: "Jan 19 (Final)", campaign: "Aiba Carusol ad", spend: 4820, messages: 245, cpr: 19.67, reach: 32500, ctr: 0.19 },
]

const preCampaignData = [
  { cycle: 1, dates: "Nov 16–18", campaign: "Aiba Carusol ad", spend: 3200, messages: 145, cpr: 22.07, reach: 21500, ctr: 0.14 },
  { cycle: 2, dates: "Nov 18–20", campaign: "Army IBA NEWS", spend: 3400, messages: 152, cpr: 22.37, reach: 22800, ctr: 0.13 },
  { cycle: 3, dates: "Nov 20–22", campaign: "Aiba Carusol ad", spend: 3600, messages: 165, cpr: 21.82, reach: 24200, ctr: 0.14 },
  { cycle: 4, dates: "Nov 22–24", campaign: "Army IBA NEWS", spend: 3800, messages: 175, cpr: 21.71, reach: 25500, ctr: 0.15 },
  { cycle: 5, dates: "Nov 24–26", campaign: "Aiba Carusol ad", spend: 4100, messages: 188, cpr: 21.81, reach: 27500, ctr: 0.15 },
  { cycle: 6, dates: "Nov 26–28", campaign: "Army IBA NEWS", spend: 4200, messages: 192, cpr: 21.88, reach: 28200, ctr: 0.15 },
  { cycle: 7, dates: "Nov 28–30", campaign: "Aiba Carusol ad", spend: 4400, messages: 205, cpr: 21.46, reach: 29500, ctr: 0.16 },
  { cycle: 8, dates: "Nov 30–Dec 02", campaign: "Army IBA NEWS", spend: 4500, messages: 210, cpr: 21.43, reach: 30200, ctr: 0.16 },
]

const transactionData = [
  { date: "Nov 16", amount: 1151.43, card: "Visa ---- 2896", reference: "SSQ0PL0QL7", vat: 172.71 },
  { date: "Nov 17", amount: 833.79, card: "Visa ---- 2896", reference: "SSQ0PL0QL7", vat: 125.07 },
  { date: "Nov 18", amount: 1151.43, card: "Visa ---- 2896", reference: "S84FH2JSTZ", vat: 172.71 },
  { date: "Nov 19", amount: 833.79, card: "Visa ---- 2896", reference: "S84FH2JSTZ", vat: 125.07 },
  { date: "Nov 20", amount: 1151.43, card: "Visa ---- 2896", reference: "S9Y0BZKFVN", vat: 172.71 },
  { date: "Nov 21", amount: 833.79, card: "Visa ---- 2896", reference: "S9Y0BZKFVN", vat: 125.07 },
  { date: "Nov 22", amount: 1151.43, card: "Visa ---- 2896", reference: "SEUPUP2F66", vat: 172.71 },
  { date: "Nov 23", amount: 1151.43, card: "Visa ---- 2896", reference: "SRH0HYIIE8", vat: 172.71 },
  { date: "Nov 24", amount: 1985.22, card: "Visa ---- 2896", reference: "SNPD4HRCJB", vat: 297.78 },
  { date: "Nov 25", amount: 1985.22, card: "Visa ---- 2896", reference: "S43LX5YBQI", vat: 297.78 },
]

export default function ReportsPage() {
  const [reportType, setReportType] = useState("cycle")
  const [dateRange, setDateRange] = useState("all")

  const downloadCSV = (data: Record<string, unknown>[], filename: string) => {
    const headers = Object.keys(data[0])
    const csvContent = [
      headers.join(","),
      ...data.map((row) => headers.map((h) => row[h]).join(",")),
    ].join("\n")
    
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${filename}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const downloadPDF = (title: string) => {
    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const currentData = reportType === "cycle" 
      ? [...preCampaignData, ...cycleData]
      : transactionData

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; }
            h1 { color: #1877F2; margin-bottom: 8px; }
            h2 { color: #333; font-size: 14px; margin-bottom: 24px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
            th { background: #1877F2; color: white; }
            tr:nth-child(even) { background: #f9f9f9; }
            .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
            .logo { font-size: 24px; font-weight: bold; color: #1877F2; }
            .summary { background: #f0f7ff; padding: 16px; border-radius: 8px; margin: 20px 0; }
            .summary h3 { margin: 0 0 8px 0; color: #1877F2; }
            .footer { margin-top: 40px; text-align: center; font-size: 11px; color: #666; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo">Army IBA Sylhet</div>
            <div>Generated: ${new Date().toLocaleDateString()}</div>
          </div>
          <h1>${title}</h1>
          <h2>Meta Ads Performance Report | Nov 16, 2025 – Jan 19, 2026</h2>
          
          <div class="summary">
            <h3>Financial Summary</h3>
            <p><strong>Pre-Campaign (Nov 16 – Jan 3):</strong> ৳119,113 + VAT ৳17,867 = ৳136,980</p>
            <p><strong>Main Campaign (Jan 4 – Jan 19):</strong> ৳65,000</p>
            <p><strong>Grand Total:</strong> ৳201,980</p>
          </div>
          
          <table>
            <thead>
              <tr>
                ${Object.keys(currentData[0]).map((key) => `<th>${key}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${currentData.map((row) => `
                <tr>
                  ${Object.values(row).map((val) => `<td>${val}</td>`).join("")}
                </tr>
              `).join("")}
            </tbody>
          </table>
          
          <div class="footer">
            <p>Army Institute of Business Administration - AIBA, Sylhet</p>
            <p>This report is generated for internal use only.</p>
          </div>
        </body>
      </html>
    `)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground">
            Export campaign data and financial reports
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="pre">Pre-Campaign (Nov 16 – Jan 3)</SelectItem>
              <SelectItem value="main">Main Campaign (Jan 4 – Jan 19)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Quick Export Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="border-border/50 hover:border-[#1877F2]/30 transition-colors cursor-pointer"
              onClick={() => downloadCSV([...preCampaignData, ...cycleData], "cycle_performance_report")}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-emerald-50 rounded-lg">
              <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-sm">Cycle Performance CSV</h3>
              <p className="text-xs text-muted-foreground">37 cycles, all metrics</p>
            </div>
            <Download className="w-4 h-4 text-muted-foreground" />
          </CardContent>
        </Card>

        <Card className="border-border/50 hover:border-[#1877F2]/30 transition-colors cursor-pointer"
              onClick={() => downloadCSV(transactionData, "transactions_report")}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-[#1877F2]/10 rounded-lg">
              <FileSpreadsheet className="w-6 h-6 text-[#1877F2]" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-sm">Transactions CSV</h3>
              <p className="text-xs text-muted-foreground">All billing records</p>
            </div>
            <Download className="w-4 h-4 text-muted-foreground" />
          </CardContent>
        </Card>

        <Card className="border-border/50 hover:border-[#1877F2]/30 transition-colors cursor-pointer"
              onClick={() => downloadPDF("Campaign Performance Report")}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-rose-50 rounded-lg">
              <FileText className="w-6 h-6 text-rose-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-sm">Full Report PDF</h3>
              <p className="text-xs text-muted-foreground">Complete overview</p>
            </div>
            <Download className="w-4 h-4 text-muted-foreground" />
          </CardContent>
        </Card>
      </div>

      {/* Data Preview */}
      <Card className="border-border/50">
        <CardHeader className="pb-0">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#1877F2]" />
                Data Preview
              </CardTitle>
              <CardDescription>Preview data before exporting</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <Tabs value={reportType} onValueChange={setReportType}>
            <TabsList className="mb-4">
              <TabsTrigger value="cycle">Cycle Performance</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
            </TabsList>

            <TabsContent value="cycle">
              <div className="rounded-lg border border-border/50 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">Cycle</TableHead>
                      <TableHead className="text-xs">Dates</TableHead>
                      <TableHead className="text-xs">Campaign</TableHead>
                      <TableHead className="text-xs text-right">Spend (৳)</TableHead>
                      <TableHead className="text-xs text-right">Messages</TableHead>
                      <TableHead className="text-xs text-right">CPR (৳)</TableHead>
                      <TableHead className="text-xs text-right">Reach</TableHead>
                      <TableHead className="text-xs text-right">CTR (%)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cycleData.slice(0, 8).map((row) => (
                      <TableRow key={row.cycle}>
                        <TableCell className="text-xs font-medium">{row.cycle}</TableCell>
                        <TableCell className="text-xs">{row.dates}</TableCell>
                        <TableCell className="text-xs">
                          <Badge variant="outline" className="text-[10px]">
                            {row.campaign}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-right">{row.spend.toLocaleString()}</TableCell>
                        <TableCell className="text-xs text-right">{row.messages}</TableCell>
                        <TableCell className="text-xs text-right">{row.cpr.toFixed(2)}</TableCell>
                        <TableCell className="text-xs text-right">{row.reach.toLocaleString()}</TableCell>
                        <TableCell className="text-xs text-right">{row.ctr}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Showing 8 of {cycleData.length} main campaign cycles. Export for full data including pre-campaign.
              </p>
            </TabsContent>

            <TabsContent value="transactions">
              <div className="rounded-lg border border-border/50 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">Date</TableHead>
                      <TableHead className="text-xs text-right">Amount (৳)</TableHead>
                      <TableHead className="text-xs">Card</TableHead>
                      <TableHead className="text-xs">Reference</TableHead>
                      <TableHead className="text-xs text-right">VAT (৳)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactionData.slice(0, 8).map((row, index) => (
                      <TableRow key={index}>
                        <TableCell className="text-xs">{row.date}</TableCell>
                        <TableCell className="text-xs text-right">{row.amount.toLocaleString()}</TableCell>
                        <TableCell className="text-xs font-mono">{row.card}</TableCell>
                        <TableCell className="text-xs font-mono">{row.reference}</TableCell>
                        <TableCell className="text-xs text-right">{row.vat.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Showing 8 of {transactionData.length} transactions. Export for full billing history.
              </p>
            </TabsContent>
          </Tabs>

          <div className="flex gap-2 mt-4">
            <Button
              onClick={() => {
                const data = reportType === "cycle" ? [...preCampaignData, ...cycleData] : transactionData
                downloadCSV(data, `${reportType}_report`)
              }}
              className="bg-[#1877F2] hover:bg-[#1877F2]/90"
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => downloadPDF(reportType === "cycle" ? "Cycle Performance Report" : "Transaction Report")}
            >
              <FileText className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report History */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Recent Exports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { name: "cycle_performance_report.csv", date: "Jan 21, 2026", size: "24 KB", type: "CSV" },
              { name: "full_campaign_report.pdf", date: "Jan 20, 2026", size: "156 KB", type: "PDF" },
              { name: "transactions_nov_dec.csv", date: "Jan 15, 2026", size: "18 KB", type: "CSV" },
            ].map((file, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-3">
                  {file.type === "CSV" ? (
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <FileText className="w-4 h-4 text-rose-600" />
                  )}
                  <div>
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{file.date} • {file.size}</p>
                  </div>
                </div>
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
